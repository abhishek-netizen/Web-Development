//jshint esversion:6
const express = require("express"); // load express library
const bodyParser = require("body-parser");
const request = require("request");
const https = require("https");

const app = express();   // call express factory to create
                                        // an instance of the express library



//to run static files such as images and all
app.use(express.static("public"));
//to make use of the details entered by the user we have to tell app to use bodyparser
app.use(bodyParser.urlencoded({extended:true}));

//sending html file to route, which responds by giving signup.html when a get request is made
app.get("/", function(req,res){
  res.sendFile(__dirname + "/signup.html");  //Note:- in get we use res
})

app.post("/",function(req,res){
  const firstName = req.body.fName;            //Note:- in post we use req
  const lastName  = req.body.lName;
  const email = req.body.email;
  console.log(firstName, lastName, email);
//mailchimp API documentation
  const data = {
    members: [
      {
        email_address:email,
        status:"subscribed",
        merge_fields: {
          FNAME:firstName,
          LNAME:lastName

        }
      }
    ]
  };
  //convert JS object into the JSON string
const jsonData = JSON.stringify(data);

const url = "https://us2.api.mailchimp.com/3.0/lists/22051cd0e7"
const options = {
  method:"POST",
  auth: "abhishek1:62f2ac1984efc0376d4b431c0ac41ed4-us2"
}



//make a https post in node js
const request = https.request(url, options, function(response){

  //if user successfully signup then res with success.html else with failure.html
  if (response.statusCode === 200) {
    res.sendFile(__dirname + "/success.html")

  }else {
    res.sendFile(__dirname + "/failure.html")

  }

  response.on("data", function(data){
    console.log(JSON.parse(data));
  })
})
// pass the request jsonData to mailchimp server
request.write(jsonData);
//done with the request
request.end();
});

//Failure route to redirect the user to go back to the signup page,Incase he/she failed to signup

app.post("/failure", function(req, res){
  res.redirect("/");
})




//to make the files run on server
app.listen(process.env.PORT || 3000, function(){
  //body parser must require, which is done in the line 14
  console.log("server is up and running on port 3000");
});


//API KEY
//62f2ac1984efc0376d4b431c0ac41ed4-us2
//LIST ID
//22051cd0e7
